# GUIÓN: TUTORIAL DE FIRMA DE DOCUMENTOS EN NOTARYPRO

## VIDEO 2: TUTORIAL - FIRMA DE DOCUMENTOS ONLINE

### ESCENA 1
**[Pantalla de usuario entrando a la web o POS]**

**NARRADOR:** 
Paso 1: Selecciona tu documento.

### ESCENA 2
**[Usuario rellenando campos en formulario]**

**NARRADOR:** 
Paso 2: Completa tus datos personales.

### ESCENA 3
**[Usuario escaneando QR para verificar identidad]**

**NARRADOR:** 
Paso 3: Verifica tu identidad con tu cédula.

### ESCENA 4
**[Usuario firmando en pantalla táctil]**

**NARRADOR:** 
Paso 4: Firma electrónicamente.

### ESCENA 5
**[Usuario recibiendo documento]**

**NARRADOR:** 
Recibe tu documento firmado.

---

**DURACIÓN ESTIMADA:** 1:00 a 1:30 minutos
**MÚSICA:** Motivadora, libre de derechos
**ESTILO VISUAL:** Profesional, corporativo, con colores institucionales: Azul (#0056A3) y Amarillo (#F9C006)
**FORMATO:** 16:9 HD (1920x1080)