# GUIÓN: CÓMO FUNCIONA NOTARYPRO

## VIDEO 1: ¿CÓMO FUNCIONA NOTARYPRO?

### ESCENA 1
**[Logo NotaryPro animado]**

**NARRADOR:** 
Bienvenido a NotaryPro, la nueva forma de gestionar documentos legales en Chile.

### ESCENA 2
**[Persona firmando en tablet]**

**NARRADOR:** 
Crea, firma y certifica documentos legales desde cualquier lugar.

### ESCENA 3
**[Firma digital validada con animación de sello de validación]**

**NARRADOR:** 
Firma electrónica certificada, cumplimiento 100% legal.

### ESCENA 4
**[Documento enviado a organismo oficial con animación de documento en movimiento]**

**NARRADOR:** 
Gestión directa ante las entidades requeridas.

### ESCENA 5
**[Cierre con logo y slogan]**

**NARRADOR:** 
NotaryPro. Legaliza tu mundo, sin moverte.

---

**DURACIÓN ESTIMADA:** 1:00 a 1:30 minutos
**MÚSICA:** Motivadora, libre de derechos
**ESTILO VISUAL:** Profesional, corporativo, con colores institucionales: Azul (#0056A3) y Amarillo (#F9C006)
**FORMATO:** 16:9 HD (1920x1080)